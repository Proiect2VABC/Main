/* A simple server in the internet domain using TCP
 The port number is passed as an argument */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <iostream>
#include <fstream>
#include <time.h>
#include <ctime>

using namespace std;

void error(const char *msg) {
	perror(msg);
	exit(1);
}

int main() {
	int sockfd, newsockfd;
	FILE * plog;
	FILE * pdate;
	int portno = 1994;

	socklen_t clilen;
	char buffer[256];
	struct sockaddr_in serv_addr, cli_addr;
	int n;
	int i;

	sockfd = socket(AF_INET, SOCK_STREAM, 0);

	if (sockfd < 0)
		error("ERROR opening socket");

	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(portno);

	if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
		error("ERROR on binding");

	while (1) {
		listen(sockfd, 5);
		clilen = sizeof(cli_addr);
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

		if (newsockfd < 0)
			error("ERROR on accept");

		bzero(buffer, 256);
		n = read(newsockfd, buffer, 255);

		if (n < 0)
			error("ERROR reading from socket");

		plog = fopen("log", "a");
		pdate = fopen("date", "a");
		time_t now = time(0);
		tm *ltm = localtime(&now);
		int time = ((ltm->tm_hour + 10) % 24) * 100 + ltm->tm_min;
		// here make the save

		cout << "Here is the message: " << buffer << " ";

		cout << time << "\n";
		for (i = 0; i < strlen(buffer); i++) {
			fprintf(plog, "%c", buffer[i]);
		}

		fprintf(plog, " ");
		fprintf(plog, "%d", time);
		fprintf(plog, "\n");

		fclose(plog);

		if (strcmp(buffer, "0") == 0) {
			cout << "Session ended(0 was sent)";
			close(newsockfd);
			close(sockfd);
			exit(0);
		}

		n = write(newsockfd, "Ack", 3);

		if (n < 0)
			error("ERROR writing to socket");
	}
	close(newsockfd);
	close(sockfd);
	return 0;
}
